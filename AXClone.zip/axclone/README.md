# AX Clone — Module Manager

Android module manager inspired by AX Manager. Import, enable/disable, and manage `.zip` module packages. **No root required. No Shizuku required.**

## Build (no PC needed)
1. Fork or upload this repo to GitHub
2. Go to **Actions** tab → **Build APK** → **Run workflow**
3. After ~3 minutes, download the APK from the Artifacts section

## Module Format
Create a `.zip` with:
```
your_module.zip
├── module_info.json   ← required
├── classes.dex        ← required (or module.jar)
└── icon.png           ← optional
```

### module_info.json
```json
{
  "id": "com.example.mymodule",
  "name": "My Module",
  "version": "1.0.0",
  "author": "YourName",
  "description": "What this module does",
  "minAppVersion": "1.0.0",
  "entryClass": "com.example.mymodule.Main"
}
```

### entryClass
Your entry class can optionally implement:
```java
public class Main {
    public void onLoad(Context ctx) {
        // called when module is imported
    }
}
```

## Features
- Import modules from any `.zip` file
- Enable / disable per module
- Module detail view
- No root, no Shizuku, no special permissions
- Dynamic DEX loading via `DexClassLoader`
- Long-press to remove module
