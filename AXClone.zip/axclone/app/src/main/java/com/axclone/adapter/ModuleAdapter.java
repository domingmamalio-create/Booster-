package com.axclone.adapter;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.axclone.R;
import com.axclone.module.ModuleInfo;
import java.util.List;

public class ModuleAdapter extends RecyclerView.Adapter<ModuleAdapter.VH> {

    public interface Listener {
        void onToggle(ModuleInfo m, boolean enabled);
        void onClick(ModuleInfo m);
        void onLongClick(ModuleInfo m);
    }

    private final List<ModuleInfo> items;
    private final Listener listener;

    public ModuleAdapter(List<ModuleInfo> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_module, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        ModuleInfo m = items.get(pos);
        h.name.setText(m.name);
        h.version.setText("v" + m.version + "  ·  " + m.author);
        h.desc.setText(m.description.isEmpty() ? "No description" : m.description);
        h.toggle.setChecked(m.enabled);
        h.toggle.setOnCheckedChangeListener((btn, checked) -> {
            m.enabled = checked;
            listener.onToggle(m, checked);
        });
        h.card.setOnClickListener(v -> listener.onClick(m));
        h.card.setOnLongClickListener(v -> { listener.onLongClick(m); return true; });
        h.badge.setText(m.enabled ? "ON" : "OFF");
        h.badge.setBackgroundResource(m.enabled ? R.drawable.badge_on : R.drawable.badge_off);
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        CardView card;
        TextView name, version, desc, badge;
        Switch toggle;
        VH(View v) {
            super(v);
            card    = v.findViewById(R.id.card);
            name    = v.findViewById(R.id.tv_name);
            version = v.findViewById(R.id.tv_version);
            desc    = v.findViewById(R.id.tv_desc);
            badge   = v.findViewById(R.id.tv_badge);
            toggle  = v.findViewById(R.id.sw_toggle);
        }
    }
}
