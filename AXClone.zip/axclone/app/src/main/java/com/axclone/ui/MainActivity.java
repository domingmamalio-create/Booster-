package com.axclone.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.Toast;
import androidx.activity.result.*;
import androidx.activity.result.contract.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.axclone.R;
import com.axclone.adapter.ModuleAdapter;
import com.axclone.module.ModuleInfo;
import com.axclone.module.ModuleManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    private ModuleManager manager;
    private List<ModuleInfo> moduleList = new ArrayList<>();
    private ModuleAdapter adapter;
    private RecyclerView rv;
    private View emptyView;

    private final ActivityResultLauncher<String[]> permLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            boolean granted = true;
            for (Boolean v : result.values()) if (!v) { granted = false; break; }
            if (granted) openFilePicker();
            else Toast.makeText(this, "Storage permission needed to import modules", Toast.LENGTH_LONG).show();
        });

    private final ActivityResultLauncher<String[]> pickLauncher =
        registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri != null) handleImport(uri);
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        manager = ModuleManager.get(this);
        rv = findViewById(R.id.rv_modules);
        emptyView = findViewById(R.id.empty_view);
        FloatingActionButton fab = findViewById(R.id.fab_import);

        // Toolbar
        setSupportActionBar(findViewById(R.id.toolbar));
        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle("Module Manager");

        // RecyclerView
        moduleList.addAll(manager.getModules());
        adapter = new ModuleAdapter(moduleList, new ModuleAdapter.Listener() {
            @Override public void onToggle(ModuleInfo m, boolean enabled) {
                manager.setEnabled(m.id, enabled);
            }
            @Override public void onClick(ModuleInfo m) {
                Intent i = new Intent(MainActivity.this, ModuleDetailActivity.class);
                i.putExtra("module_id", m.id);
                startActivity(i);
            }
            @Override public void onLongClick(ModuleInfo m) {
                showDeleteDialog(m);
            }
        });
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);
        updateEmpty();

        fab.setOnClickListener(v -> requestImport());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        if (item.getItemId() == R.id.action_about) {
            showAbout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void requestImport() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            openFilePicker();
        } else {
            String[] perms = {Manifest.permission.READ_EXTERNAL_STORAGE};
            boolean granted = ContextCompat.checkSelfPermission(this, perms[0]) == PackageManager.PERMISSION_GRANTED;
            if (granted) openFilePicker();
            else permLauncher.launch(perms);
        }
    }

    private void openFilePicker() {
        pickLauncher.launch(new String[]{"application/zip", "application/octet-stream", "*/*"});
    }

    private void handleImport(Uri uri) {
        View root = findViewById(android.R.id.content);
        Snackbar.make(root, "Importing module...", Snackbar.LENGTH_INDEFINITE).show();

        new Thread(() -> {
            try {
                File tmp = new File(getCacheDir(), "import_" + System.currentTimeMillis() + ".zip");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[8192]; int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                }

                ModuleManager.ImportResult res = manager.importModule(tmp);
                tmp.delete();

                runOnUiThread(() -> {
                    if (res.success) {
                        moduleList.clear();
                        moduleList.addAll(manager.getModules());
                        adapter.notifyDataSetChanged();
                        updateEmpty();
                        Snackbar.make(root, "✓ " + res.module.name + " imported!", Snackbar.LENGTH_SHORT).show();
                    } else {
                        new AlertDialog.Builder(this)
                            .setTitle("Import Failed")
                            .setMessage(res.error)
                            .setPositiveButton("OK", null)
                            .show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() ->
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void showDeleteDialog(ModuleInfo m) {
        new AlertDialog.Builder(this)
            .setTitle("Remove Module")
            .setMessage("Remove \"" + m.name + "\"?")
            .setPositiveButton("Remove", (d, w) -> {
                manager.removeModule(m.id);
                moduleList.clear();
                moduleList.addAll(manager.getModules());
                adapter.notifyDataSetChanged();
                updateEmpty();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void updateEmpty() {
        emptyView.setVisibility(moduleList.isEmpty() ? View.VISIBLE : View.GONE);
        rv.setVisibility(moduleList.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
            .setTitle("AX Clone — Module Manager")
            .setMessage("Version 1.0.0\n\nImport .zip module packages.\nNo root · No Shizuku required.\n\nModule format:\n  module_info.json\n  classes.dex or module.jar\n  (optional) icon.png")
            .setPositiveButton("OK", null)
            .show();
    }
}
