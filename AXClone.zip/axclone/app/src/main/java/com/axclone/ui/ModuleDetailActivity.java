package com.axclone.ui;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.axclone.R;
import com.axclone.module.ModuleInfo;
import com.axclone.module.ModuleManager;
import java.text.SimpleDateFormat;
import java.util.*;

public class ModuleDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_detail);

        String moduleId = getIntent().getStringExtra("module_id");
        if (moduleId == null) { finish(); return; }

        ModuleInfo info = null;
        for (ModuleInfo m : ModuleManager.get(this).getModules()) {
            if (m.id.equals(moduleId)) { info = m; break; }
        }
        if (info == null) { finish(); return; }

        setSupportActionBar(findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(info.name);
        }

        ((TextView) findViewById(R.id.tv_name)).setText(info.name);
        ((TextView) findViewById(R.id.tv_id)).setText(info.id);
        ((TextView) findViewById(R.id.tv_version)).setText("v" + info.version);
        ((TextView) findViewById(R.id.tv_author)).setText(info.author);
        ((TextView) findViewById(R.id.tv_desc)).setText(info.description.isEmpty() ? "No description" : info.description);
        ((TextView) findViewById(R.id.tv_entry)).setText(info.entryClass.isEmpty() ? "None" : info.entryClass);
        ((TextView) findViewById(R.id.tv_path)).setText(info.modulePath);

        String date = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
            .format(new Date(info.installedAt));
        ((TextView) findViewById(R.id.tv_installed)).setText(date);

        Switch sw = findViewById(R.id.sw_enabled);
        sw.setChecked(info.enabled);
        ModuleInfo finalInfo = info;
        sw.setOnCheckedChangeListener((b, checked) ->
            ModuleManager.get(this).setEnabled(finalInfo.id, checked));
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
