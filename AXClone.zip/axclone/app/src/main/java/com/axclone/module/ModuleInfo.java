package com.axclone.module;

import org.json.JSONObject;

public class ModuleInfo {
    public String id;
    public String name;
    public String version;
    public String author;
    public String description;
    public String minAppVersion;
    public String entryClass;
    public String iconPath;
    public boolean enabled;
    public long installedAt;
    public String modulePath;

    public static ModuleInfo fromJson(JSONObject j) {
        ModuleInfo m = new ModuleInfo();
        try {
            m.id          = j.optString("id", "unknown");
            m.name        = j.optString("name", "Unnamed Module");
            m.version     = j.optString("version", "1.0");
            m.author      = j.optString("author", "Unknown");
            m.description = j.optString("description", "");
            m.minAppVersion = j.optString("minAppVersion", "1.0.0");
            m.entryClass  = j.optString("entryClass", "");
        } catch (Exception ignored) {}
        return m;
    }

    public JSONObject toJson() {
        JSONObject j = new JSONObject();
        try {
            j.put("id", id);
            j.put("name", name);
            j.put("version", version);
            j.put("author", author);
            j.put("description", description);
            j.put("minAppVersion", minAppVersion);
            j.put("entryClass", entryClass);
            j.put("enabled", enabled);
            j.put("installedAt", installedAt);
            j.put("modulePath", modulePath);
        } catch (Exception ignored) {}
        return j;
    }
}
