package com.axclone.module;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class ModuleManager {

    private static final String TAG = "ModuleManager";
    private static final String MODULES_DIR = "modules";
    private static final String INDEX_FILE = "modules_index.json";
    private static ModuleManager instance;

    private final Context ctx;
    private final File modulesDir;
    private final List<ModuleInfo> loadedModules = new ArrayList<>();

    private ModuleManager(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.modulesDir = new File(ctx.getFilesDir(), MODULES_DIR);
        if (!modulesDir.exists()) modulesDir.mkdirs();
        loadIndex();
    }

    public static synchronized ModuleManager get(Context ctx) {
        if (instance == null) instance = new ModuleManager(ctx);
        return instance;
    }

    // ── IMPORT from ZIP ───────────────────────────────────────────────────
    public ImportResult importModule(File zipFile) {
        ImportResult result = new ImportResult();
        File tempDir = new File(ctx.getCacheDir(), "import_" + System.currentTimeMillis());
        tempDir.mkdirs();

        try {
            // 1. Extract ZIP
            extractZip(zipFile, tempDir);

            // 2. Read module_info.json
            File infoFile = new File(tempDir, "module_info.json");
            if (!infoFile.exists()) {
                result.success = false;
                result.error = "module_info.json not found in package";
                return result;
            }

            String infoStr = readFile(infoFile);
            JSONObject infoJson = new JSONObject(infoStr);
            ModuleInfo info = ModuleInfo.fromJson(infoJson);

            if (info.id == null || info.id.isEmpty() || info.id.equals("unknown")) {
                result.success = false;
                result.error = "Module ID is missing in module_info.json";
                return result;
            }

            // 3. Check for classes.dex or module.jar
            File dexFile = new File(tempDir, "classes.dex");
            File jarFile = new File(tempDir, "module.jar");
            if (!dexFile.exists() && !jarFile.exists()) {
                result.success = false;
                result.error = "No classes.dex or module.jar found in package";
                return result;
            }

            // 4. Remove existing if same ID
            removeModuleById(info.id);

            // 5. Copy to modules dir
            File moduleDir = new File(modulesDir, info.id);
            moduleDir.mkdirs();
            copyDir(tempDir, moduleDir);

            // 6. Set metadata
            info.modulePath = moduleDir.getAbsolutePath();
            info.installedAt = System.currentTimeMillis();
            info.enabled = true;

            // 7. Load it
            loadModule(info, moduleDir);

            // 8. Save index
            loadedModules.removeIf(m -> m.id.equals(info.id));
            loadedModules.add(info);
            saveIndex();

            result.success = true;
            result.module = info;
            Log.d(TAG, "Module imported: " + info.name + " v" + info.version);

        } catch (Exception e) {
            result.success = false;
            result.error = e.getMessage();
            Log.e(TAG, "Import failed", e);
        } finally {
            deleteDir(tempDir);
        }
        return result;
    }

    // ── LOAD MODULE (DexClassLoader) ─────────────────────────────────────
    private void loadModule(ModuleInfo info, File moduleDir) {
        try {
            File dex = new File(moduleDir, "classes.dex");
            if (!dex.exists()) dex = new File(moduleDir, "module.jar");
            if (!dex.exists()) return;

            File optDir = new File(ctx.getCacheDir(), "opt_" + info.id);
            optDir.mkdirs();

            dalvik.system.DexClassLoader loader = new dalvik.system.DexClassLoader(
                dex.getAbsolutePath(),
                optDir.getAbsolutePath(),
                null,
                ctx.getClassLoader()
            );

            if (info.entryClass != null && !info.entryClass.isEmpty()) {
                Class<?> entryClazz = loader.loadClass(info.entryClass);
                Object entry = entryClazz.newInstance();
                // Call onLoad if available
                try {
                    entryClazz.getMethod("onLoad", Context.class).invoke(entry, ctx);
                } catch (NoSuchMethodException ignored) {}
                Log.d(TAG, "Entry class loaded: " + info.entryClass);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not load entry class for " + info.id + ": " + e.getMessage());
        }
    }

    // ── ENABLE / DISABLE ─────────────────────────────────────────────────
    public void setEnabled(String id, boolean enabled) {
        for (ModuleInfo m : loadedModules) {
            if (m.id.equals(id)) { m.enabled = enabled; break; }
        }
        saveIndex();
    }

    // ── REMOVE ───────────────────────────────────────────────────────────
    public boolean removeModule(String id) {
        removeModuleById(id);
        saveIndex();
        return true;
    }

    private void removeModuleById(String id) {
        loadedModules.removeIf(m -> m.id.equals(id));
        File dir = new File(modulesDir, id);
        if (dir.exists()) deleteDir(dir);
    }

    // ── INDEX ─────────────────────────────────────────────────────────────
    private void loadIndex() {
        File idx = new File(modulesDir, INDEX_FILE);
        if (!idx.exists()) return;
        try {
            String s = readFile(idx);
            JSONArray arr = new JSONArray(s);
            loadedModules.clear();
            for (int i = 0; i < arr.length(); i++) {
                ModuleInfo m = ModuleInfo.fromJson(arr.getJSONObject(i));
                if (new File(m.modulePath).exists()) loadedModules.add(m);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to load index", e);
        }
    }

    private void saveIndex() {
        try {
            JSONArray arr = new JSONArray();
            for (ModuleInfo m : loadedModules) arr.put(m.toJson());
            writeFile(new File(modulesDir, INDEX_FILE), arr.toString(2));
        } catch (Exception e) {
            Log.e(TAG, "Failed to save index", e);
        }
    }

    public List<ModuleInfo> getModules() {
        return Collections.unmodifiableList(loadedModules);
    }

    // ── UTILITIES ─────────────────────────────────────────────────────────
    private void extractZip(File zip, File dest) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zip))) {
            ZipEntry entry;
            byte[] buf = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                File out = new File(dest, entry.getName());
                if (entry.isDirectory()) { out.mkdirs(); continue; }
                out.getParentFile().mkdirs();
                try (FileOutputStream fos = new FileOutputStream(out)) {
                    int len;
                    while ((len = zis.read(buf)) > 0) fos.write(buf, 0, len);
                }
                zis.closeEntry();
            }
        }
    }

    private void copyDir(File src, File dest) throws IOException {
        if (src.isDirectory()) {
            dest.mkdirs();
            for (File f : src.listFiles()) copyDir(f, new File(dest, f.getName()));
        } else {
            try (InputStream in = new FileInputStream(src);
                 OutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192]; int len;
                while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            }
        }
    }

    private void deleteDir(File f) {
        if (f.isDirectory()) for (File c : f.listFiles()) deleteDir(c);
        f.delete();
    }

    private String readFile(File f) throws IOException {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
    }

    private void writeFile(File f, String content) throws IOException {
        try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            w.write(content);
        }
    }

    // ── RESULT ────────────────────────────────────────────────────────────
    public static class ImportResult {
        public boolean success;
        public String error;
        public ModuleInfo module;
    }
}
